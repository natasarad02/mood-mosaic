import json
import boto3
import uuid
from datetime import datetime

dynamodb = boto3.resource('dynamodb', endpoint_url='http://localstack:4566')
table = dynamodb.Table('Moods')

def lambda_handler(event, context):
    method = event.get('httpMethod')

    if method == 'POST': # Proverava da li je POST metoda, odnosno da li korisnik unosi novo raspolozenje
        body = json.loads(event.get('body', '{}')) # default je {}
        emoji = body.get('emoji', ':)') # default raspolozenje je :)
        text = body.get('text', '') # poruka uz raspolozenje

        moodItem = {
            'id': str(uuid.uuid4()),
            'emoji': emoji, 
            'text': text,
            'timestamp': datetime.utcnow().isoformat()
        }

        table.put_item(Item=moodItem)
        return {'statusCode': 200, 'body': json.dumps({'message':'ok', 'item':moodItem})}
    elif method == 'GET': # Proverava da li dobavlja sva raspolozenja iz tabele
        resp = table.scan()
        items = sorted(resp.get('Items', []), key=lambda x: x.get('timestamp', ''))
        return {'statusCode': 200, 'body': json.dumps(items)}
    else:
        return {'statusCode':400,'body':'Unsupported method'}
